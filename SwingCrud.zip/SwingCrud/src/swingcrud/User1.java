package swingcrud;

/**
 *
 * @author JAMES
 */
public class User1 {
    String fname,lname,id,id1;
    public User1(String fname,String lname,String id1, String id){
        this.fname = fname;
        this.lname = lname;
        this.id1 = id1;
        this.id = id;
    }
    
    //getters
    public String getLname(){
        return this.lname;
    }
    public String getFname(){
        return this.fname;
    }
    public String getId1(){
        return this.id1;
    }
    public String getId(){
        return this.id;
    }
    
}
