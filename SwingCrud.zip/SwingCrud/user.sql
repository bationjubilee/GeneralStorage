-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2021 at 03:00 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `id_number` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `fname`, `lname`, `id_number`) VALUES
(10, 'Toyota Fortuner', 'Black Silver', 'CAR001'),
(11, 'Chevrolet Trailblzer', 'Sparkle Silver', 'CAR002'),
(13, 'Hyundai Eon', 'Envy Green', 'CAR004'),
(15, 'Chevrolet Corvette', 'Matte Red', 'CAR005'),
(16, 'KIA Picanto', 'White', 'CAR003');

-- --------------------------------------------------------

--
-- Table structure for table `student1`
--

CREATE TABLE `student1` (
  `id1` int(11) NOT NULL,
  `fname1` varchar(20) NOT NULL,
  `lname1` varchar(20) NOT NULL,
  `id_number1` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student1`
--

INSERT INTO `student1` (`id1`, `fname1`, `lname1`, `id_number1`) VALUES
(16, 'Jubilee Bation', '09977430719', 'CUST001'),
(17, 'Mary Joy Bailio', '094826489234', 'CUST002'),
(18, 'Threcia Laurente', '092834723047', 'CUST003'),
(19, 'Jill Catapang', '08797865354', 'CUST004');

-- --------------------------------------------------------

--
-- Table structure for table `student2`
--

CREATE TABLE `student2` (
  `id2` int(11) NOT NULL,
  `fname2` varchar(20) NOT NULL,
  `lname2` varchar(20) NOT NULL,
  `id_number3` varchar(20) NOT NULL,
  `id_number2` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student2`
--

INSERT INTO `student2` (`id2`, `fname2`, `lname2`, `id_number3`, `id_number2`) VALUES
(1, 'Toyota Fortuner', 'Jubilee Bation', '9500', 'RENT001'),
(2, 'Chevrolet Trailblzer', 'Threcia Laurente', '6000', 'RENT002'),
(3, 'Hyundai Eon', 'Jill Catapang', '15000', 'RENT003'),
(4, 'KIA Picanto', 'Mary Joy Bailio', '3000', 'RENT004');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_number` (`id_number`);

--
-- Indexes for table `student1`
--
ALTER TABLE `student1`
  ADD PRIMARY KEY (`id1`),
  ADD UNIQUE KEY `id_number1` (`id_number1`);

--
-- Indexes for table `student2`
--
ALTER TABLE `student2`
  ADD PRIMARY KEY (`id2`),
  ADD UNIQUE KEY `id_number2` (`id_number2`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `student1`
--
ALTER TABLE `student1`
  MODIFY `id1` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `student2`
--
ALTER TABLE `student2`
  MODIFY `id2` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
